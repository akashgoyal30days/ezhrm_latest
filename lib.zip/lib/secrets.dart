class Secrets {
  // Add your Google Maps API Key here
  static const API_KEY = 'AIzaSyB_8I9yftphPleqH30xkfQPxcQ3jmx8FcQ';
}
